<?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $name = $_POST["name"];
                $email = $_POST["email"];
                $subject = $_POST["subject"];
          
                $to = "agsform95@gmail.com";
                $headers = "From: $email";
          
                if (mail($to, $subject, $name, $headers)) {
                    echo "Email envoyé avec succès";
                } else {
                    echo "L'envoi de l'e-mail a échoué";
                }
            }
            ?>